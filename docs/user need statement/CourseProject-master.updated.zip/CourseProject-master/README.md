# Headline 1
## Headline 2
### Headline 3
Paragraph a of text.

Next paragraph.

## Headline lower down
Emphasis *is* **fun**.  ~strike through~, code view: `Console.WriteLine ("Test"); `

[A link to google]  (http://google.com)
 
1. This is first
2. This is second
3. This is third

- an item
- another item
- third item

| Header | Second header |
|-|-|
| tag | Data |
| tag 2 | data2 |
